from dataclasses import dataclass
from typing import Dict, List, Optional

@dataclass
class MenuItem:
    """Represents a menu item"""
    name: str
    price: int
    description: str
    category: str
    available: bool = True

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "price": self.price,
            "description": self.description,
            "category": self.category,
            "available": self.available
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'MenuItem':
        return cls(
            name=data["name"],
            price=data["price"],
            description=data["description"],
            category=data["category"],
            available=data.get("available", True)
        )

@dataclass
class MenuCategory:
    """Represents a menu category"""
    name: str
    emoji: str
    items: List[MenuItem]
    active: bool = True

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "emoji": self.emoji,
            "items": [item.to_dict() for item in self.items],
            "active": self.active
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'MenuCategory':
        items = [MenuItem.from_dict(item_data) for item_data in data.get("items", [])]
        return cls(
            name=data["name"],
            emoji=data.get("emoji", "🍽️"),
            items=items,
            active=data.get("active", True)
        )

    def get_available_items(self) -> List[MenuItem]:
        """Get only available items"""
        return [item for item in self.items if item.available]

    def add_item(self, item: MenuItem):
        """Add item to category"""
        self.items.append(item)

    def remove_item(self, item_name: str):
        """Remove item by name"""
        self.items = [item for item in self.items if item.name != item_name]

    def get_item(self, item_name: str) -> Optional[MenuItem]:
        """Get item by name"""
        for item in self.items:
            if item.name == item_name:
                return item
        return None
