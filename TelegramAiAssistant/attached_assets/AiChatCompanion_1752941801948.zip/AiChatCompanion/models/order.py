from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict
from enum import Enum

class OrderStatus(Enum):
    PENDING = "pending"
    PREPARING = "preparing" 
    READY = "ready"
    COMPLETED = "completed"
    REJECTED = "rejected"

@dataclass
class Order:
    """Represents a customer order"""
    id: str
    user_id: int
    username: str
    item_name: str
    item_price: int
    status: OrderStatus
    created_at: datetime
    updated_at: Optional[datetime] = None
    assigned_to: Optional[int] = None
    staff_message_id: Optional[int] = None
    notes: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "username": self.username,
            "item_name": self.item_name,
            "item_price": self.item_price,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "assigned_to": self.assigned_to,
            "staff_message_id": self.staff_message_id,
            "notes": self.notes
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'Order':
        return cls(
            id=data["id"],
            user_id=data["user_id"],
            username=data["username"],
            item_name=data["item_name"],
            item_price=data["item_price"],
            status=OrderStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            assigned_to=data.get("assigned_to"),
            staff_message_id=data.get("staff_message_id"),
            notes=data.get("notes")
        )

    def update_status(self, new_status: OrderStatus, staff_user_id: Optional[int] = None):
        """Update order status"""
        self.status = new_status
        self.updated_at = datetime.now()
        if staff_user_id:
            self.assigned_to = staff_user_id

    def get_status_emoji(self) -> str:
        """Get emoji for current status"""
        status_emojis = {
            OrderStatus.PENDING: "⏳",
            OrderStatus.PREPARING: "🔥", 
            OrderStatus.READY: "✅",
            OrderStatus.COMPLETED: "🎉",
            OrderStatus.REJECTED: "❌"
        }
        return status_emojis.get(self.status, "❓")

    def get_status_text(self) -> str:
        """Get human readable status"""
        status_texts = {
            OrderStatus.PENDING: "In attesa",
            OrderStatus.PREPARING: "In preparazione",
            OrderStatus.READY: "Pronto",
            OrderStatus.COMPLETED: "Completato", 
            OrderStatus.REJECTED: "Rifiutato"
        }
        return status_texts.get(self.status, "Sconosciuto")

@dataclass
class SponsorRequest:
    """Represents a sponsor request"""
    id: str
    user_id: int
    username: str
    status: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    staff_message_id: Optional[int] = None
    notes: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "username": self.username,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "staff_message_id": self.staff_message_id,
            "notes": self.notes
        }

@dataclass 
class Application:
    """Represents a job application"""
    id: str
    user_id: int
    username: str
    name: str
    age: str
    role: str
    status: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    staff_message_id: Optional[int] = None
    notes: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "username": self.username,
            "name": self.name,
            "age": self.age,
            "role": self.role,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "staff_message_id": self.staff_message_id,
            "notes": self.notes
        }
