from aiogram import Router, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import Database
from utils.keyboards import create_recruitment_start_keyboard, create_staff_application_keyboard
from utils.messages import format_application_message, format_staff_application_message
from config import RESTAURANT_NAME

class RecruitmentStates(StatesGroup):
    waiting_minecraft_name = State()
    waiting_telegram_handle = State()
    waiting_presentation = State()
    waiting_motivation = State()
    waiting_experience = State()
    waiting_hours = State()
    waiting_suggestions = State()
    waiting_situation = State()
    waiting_additional = State()

def register_handlers(dp, db: Database, bot: Bot):
    router = Router()

    @router.message(Command("curriculum"))
    async def curriculum_command(message: Message):
        """Handle /curriculum command"""
        keyboard = create_recruitment_start_keyboard()
        recruitment_text = f"""
📝 <b>Candidatura - {RESTAURANT_NAME}</b>

🌟 Vuoi lavorare nel miglior ristorante?

🏢 <b>Posizioni disponibili:</b>
• 👨‍🍳 Cuoco
• 🛎️ Cameriere  
• 💼 Manager
• 🧹 Addetto alle pulizie
• 🚚 Fattorino

✨ <b>Cosa offriamo:</b>
• 👥 Team affiatato
• 🏆 Opportunità di crescita
• 💰 Compensi competitivi

🚀 Clicca il bottone per iniziare la tua candidatura!
        """
        
        await message.answer(
            recruitment_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )

    @router.callback_query(lambda c: c.data == "start_application")
    async def start_application_callback(callback: CallbackQuery, state: FSMContext):
        """Start application process"""
        await callback.message.edit_text(
            "📝 <b>Candidatura - Modulo Completo</b>\n\n"
            "🎮 <b>Nome Minecraft:</b>\n"
            "Scrivi il tuo username di Minecraft:",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_minecraft_name)
        await callback.answer()

    @router.message(RecruitmentStates.waiting_minecraft_name)
    async def process_minecraft_name(message: Message, state: FSMContext):
        """Process minecraft name"""
        minecraft_name = message.text.strip()
        
        if len(minecraft_name) < 3:
            await message.reply("❌ Il nome Minecraft deve essere almeno di 3 caratteri. Riprova:")
            return
            
        await state.update_data(minecraft_name=minecraft_name)
        await message.reply(
            "📱 <b>@Telegram:</b>\n\n"
            "Scrivi il tuo username Telegram (con @):",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_telegram_handle)

    @router.message(RecruitmentStates.waiting_telegram_handle)
    async def process_telegram_handle(message: Message, state: FSMContext):
        """Process telegram handle"""
        telegram_handle = message.text.strip()
        
        if not telegram_handle.startswith('@'):
            await message.reply("❌ L'username deve iniziare con @. Riprova:")
            return
            
        await state.update_data(telegram_handle=telegram_handle)
        await message.reply(
            "🗣️ <b>Presentati:</b>\n\n"
            "Scrivici qualcosa di te, i tuoi interessi, hobby, ecc:",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_presentation)

    @router.message(RecruitmentStates.waiting_presentation)
    async def process_presentation(message: Message, state: FSMContext):
        """Process presentation"""
        presentation = message.text.strip()
        
        if len(presentation) < 10:
            await message.reply("❌ La presentazione deve essere più dettagliata (almeno 10 caratteri):")
            return
            
        await state.update_data(presentation=presentation)
        await message.reply(
            "💡 <b>Per quale motivo hai deciso di candidarti?</b>\n\n"
            "Spiegaci cosa ti ha spinto a voler lavorare con noi:",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_motivation)

    @router.message(RecruitmentStates.waiting_motivation)
    async def process_motivation(message: Message, state: FSMContext):
        """Process motivation"""
        motivation = message.text.strip()
        
        await state.update_data(motivation=motivation)
        await message.reply(
            "👨‍🍳 <b>Hai qualche esperienza in ambito culinario e da cassiere?</b>\n\n"
            "Descrivi le tue esperienze precedenti:",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_experience)

    @router.message(RecruitmentStates.waiting_experience)
    async def process_experience(message: Message, state: FSMContext):
        """Process experience"""
        experience = message.text.strip()
        
        await state.update_data(experience=experience)
        await message.reply(
            "⏰ <b>Quante ore fai normalmente?</b>\n\n"
            "Indica quante ore al giorno puoi dedicare al lavoro:",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_hours)

    @router.message(RecruitmentStates.waiting_hours)
    async def process_hours(message: Message, state: FSMContext):
        """Process working hours"""
        hours = message.text.strip()
        
        await state.update_data(hours=hours)
        await message.reply(
            "💡 <b>Hai qualche consiglio da dare per migliorare l'azienda?</b>\n\n"
            "Condividi le tue idee:",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_suggestions)

    @router.message(RecruitmentStates.waiting_suggestions)
    async def process_suggestions(message: Message, state: FSMContext):
        """Process suggestions"""
        suggestions = message.text.strip()
        
        await state.update_data(suggestions=suggestions)
        await message.reply(
            "⚖️ <b>Situazione ipotetica:</b>\n\n"
            "Se un dipendente si comporta male, insultando tutti, o magari ha rubato 3/4 di ingredienti. Tu cosa faresti se te ne accorgessi?",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_situation)

    @router.message(RecruitmentStates.waiting_situation)
    async def process_situation(message: Message, state: FSMContext):
        """Process situation response"""
        situation = message.text.strip()
        
        await state.update_data(situation=situation)
        await message.reply(
            "✍️ <b>Hai altro da scrivere?</b>\n\n"
            "Fallo pure in questo punto (oppure scrivi 'no' per completare):",
            parse_mode="HTML"
        )
        await state.set_state(RecruitmentStates.waiting_additional)

    @router.message(RecruitmentStates.waiting_additional)
    async def process_additional_and_complete(message: Message, state: FSMContext, bot: Bot):
        """Process additional info and complete application"""
        additional = message.text.strip()
        
        # Get all stored data
        data = await state.get_data()
        
        # Clear state
        await state.clear()
        
        user = message.from_user
        username = f"@{user.username}" if user.username else f"{user.first_name}"
        
        # Create comprehensive application
        app_id = db.create_comprehensive_application(
            user.id, username, 
            data.get("minecraft_name"),
            data.get("telegram_handle"),
            data.get("presentation"),
            data.get("motivation"),
            data.get("experience"),
            data.get("hours"),
            data.get("suggestions"),
            data.get("situation"),
            additional
        )
        
        # Send confirmation to user
        await message.reply(
            f"✅ <b>Candidatura completa inviata!</b>\n\n"
            f"📋 <b>ID Candidatura:</b> <code>{app_id}</code>\n\n"
            f"⏳ Il nostro team HR esaminerà la tua candidatura completa!\n"
            f"Ti contatteremo presto! 🎯",
            parse_mode="HTML"
        )

        # Send to staff group
        staff_group_id = db.get_staff_group_id()
        applications_topic_id = db.get_topic_id("applications")
        
        if staff_group_id and applications_topic_id:
            keyboard = create_staff_application_keyboard(app_id)
            staff_message = format_comprehensive_staff_application_message(app_id, data, username)
            
            staff_msg = await bot.send_message(
                chat_id=staff_group_id,
                message_thread_id=applications_topic_id,
                text=staff_message,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            
            # Save staff message ID
            db.set_application_staff_message(app_id, staff_msg.message_id)

    # Staff handlers for applications
    @router.callback_query(lambda c: c.data.startswith("app_"))
    async def handle_staff_application_action(callback: CallbackQuery, bot: Bot):
        """Handle staff actions on applications"""
        try:
            action, app_id = callback.data.split("_", 1)
            application = db.get_application(app_id)
            
            if not application:
                await callback.answer("Candidatura non trovata!", show_alert=True)
                return
            
            staff_user = callback.from_user
            staff_name = f"@{staff_user.username}" if staff_user.username else staff_user.first_name
            
            if action == "approve":
                # Approve application
                db.update_application_status(app_id, "approved")
                
                # Update staff message
                updated_message = format_comprehensive_staff_application_message(
                    app_id, application, application["username"], "approved", staff_name
                )
                
                await callback.message.edit_text(
                    updated_message,
                    parse_mode="HTML"
                )
                
                # Notify applicant
                await bot.send_message(
                    chat_id=application["user_id"],
                    text=f"🎉 <b>Candidatura approvata!</b>\n\n"
                         f"✅ Congratulazioni! La tua candidatura è stata accettata da {staff_name}!\n"
                         f"📋 <b>ID Candidatura:</b> <code>{app_id}</code>\n\n"
                         f"🎯 Sarai presto contattato per i prossimi passi!",
                    parse_mode="HTML"
                )
                
                await callback.answer("Candidatura approvata!")
                
            elif action == "reject":
                # Reject application
                db.update_application_status(app_id, "rejected")
                
                # Update staff message
                updated_message = format_comprehensive_staff_application_message(
                    app_id, application, application["username"], "rejected", staff_name
                )
                
                await callback.message.edit_text(
                    updated_message,
                    parse_mode="HTML"
                )
                
                # Notify applicant
                await bot.send_message(
                    chat_id=application["user_id"],
                    text=f"😔 <b>Candidatura non accettata</b>\n\n"
                         f"❌ Spiacenti, la tua candidatura non è stata accettata questa volta.\n"
                         f"📋 <b>ID Candidatura:</b> <code>{app_id}</code>\n\n"
                         f"💪 Non scoraggiarti! Puoi riprovare in futuro!",
                    parse_mode="HTML"
                )
                
                await callback.answer("Candidatura rifiutata!")
                
        except Exception as e:
            await callback.answer("Errore nell'azione!", show_alert=True)

    dp.include_router(router)

def format_comprehensive_staff_application_message(app_id: str, data: dict, username: str, status: str = "pending", staff_name: str = None) -> str:
    """Format comprehensive staff application message"""
    
    status_emojis = {
        "pending": "⏳",
        "approved": "✅", 
        "rejected": "❌"
    }
    
    status_texts = {
        "pending": "In attesa",
        "approved": "Approvata", 
        "rejected": "Rifiutata"
    }
    
    emoji = status_emojis.get(status, "❓")
    status_text = status_texts.get(status, "Sconosciuto")
    
    message = f"""
📝 <b>Candidatura #{app_id[-8:]}</b>

👤 <b>Da:</b> {username}
🎮 <b>Minecraft:</b> {data.get('minecraft_name', 'N/A')}
📱 <b>Telegram:</b> {data.get('telegram_handle', 'N/A')}

🗣️ <b>Presentazione:</b>
{data.get('presentation', 'N/A')}

💡 <b>Motivazione:</b>
{data.get('motivation', 'N/A')}

👨‍🍳 <b>Esperienza:</b>
{data.get('experience', 'N/A')}

⏰ <b>Ore disponibili:</b>
{data.get('hours', 'N/A')}

💡 <b>Suggerimenti:</b>
{data.get('suggestions', 'N/A')}

⚖️ <b>Situazione ipotetica:</b>
{data.get('situation', 'N/A')}

✍️ <b>Note aggiuntive:</b>
{data.get('additional', 'N/A') if data.get('additional') != 'no' else 'Nessuna'}

{emoji} <b>Stato:</b> {status_text}"""
    
    if staff_name and status != "pending":
        message += f"\n👨‍💼 <b>Gestito da:</b> {staff_name}"
    
    return message