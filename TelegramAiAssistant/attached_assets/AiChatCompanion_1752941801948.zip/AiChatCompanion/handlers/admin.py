from aiogram import Router, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database import Database
from utils.keyboards import create_admin_menu_keyboard, create_menu_edit_keyboard
from config import ADMIN_IDS, EMOJI

class AdminStates(StatesGroup):
    waiting_for_category = State()
    waiting_for_item_name = State()
    waiting_for_item_price = State()
    waiting_for_item_description = State()
    waiting_dish_name = State()
    waiting_dish_price = State()
    waiting_edit_price = State()

def register_handlers(dp, db: Database, bot: Bot):
    router = Router()

    def is_admin(user_id: int) -> bool:
        return user_id in ADMIN_IDS

    @router.message(Command("setup_staff"))
    async def setup_staff_command(message: Message):
        """Handle /setup_staff command"""
        if not is_admin(message.from_user.id):
            await message.answer("❌ Solo gli admin possono configurare lo staff!")
            return
            
        # Get current group ID if this is a group
        if message.chat.type in ["supergroup", "group"]:
            group_id = message.chat.id
            
            # Save group ID
            db.set_staff_group_id(group_id)
            
            await message.answer(
                f"✅ <b>Gruppo Staff Configurato!</b>\n\n"
                f"🆔 <b>Group ID:</b> <code>{group_id}</code>\n\n"
                f"📋 <b>Prossimi passi:</b>\n"
                f"1. Abilita i Topics in questo gruppo\n"
                f"2. Il bot creerà automaticamente i topic necessari\n"
                f"3. Usa /create_topics per creare i topic se necessario",
                parse_mode="HTML"
            )
        else:
            await message.answer(
                "❌ Questo comando deve essere usato nel gruppo staff!\n\n"
                "📋 <b>Come configurare:</b>\n"
                "1. Crea un supergruppo su Telegram\n"
                "2. Aggiungi il bot come admin\n" 
                "3. Abilita i Topics\n"
                "4. Usa questo comando nel gruppo",
                parse_mode="HTML"
            )

    @router.message(Command("create_topics"))
    async def create_topics_command(message: Message, bot: Bot):
        """Handle /create_topics command"""
        if not is_admin(message.from_user.id):
            await message.answer("❌ Solo gli admin possono creare i topics!")
            return
            
        if message.chat.type not in ["supergroup"]:
            await message.answer("❌ I topics funzionano solo nei supergruppi!")
            return
            
        try:
            # Create forum topics
            topics_created = []
            
            # Check if topics already exist
            if not db.get_topic_id("orders"):
                orders_topic = await bot.create_forum_topic(
                    chat_id=message.chat.id,
                    name="📦 Ordini",
                    icon_color=0x6FB9F0
                )
                db.set_topic_id("orders", orders_topic.message_thread_id)
                topics_created.append("📦 Ordini")
            
            if not db.get_topic_id("sponsors"):
                sponsors_topic = await bot.create_forum_topic(
                    chat_id=message.chat.id,
                    name="📜 Annunci Sponsor", 
                    icon_color=0xFFD67E
                )
                db.set_topic_id("sponsors", sponsors_topic.message_thread_id)
                topics_created.append("📜 Annunci Sponsor")
            
            if not db.get_topic_id("recruitment"):
                recruitment_topic = await bot.create_forum_topic(
                    chat_id=message.chat.id,
                    name="📝 Candidature",
                    icon_color=0x8EEE98
                )
                db.set_topic_id("recruitment", recruitment_topic.message_thread_id)
                topics_created.append("📝 Candidature")
            
            if topics_created:
                topics_list = "\n".join([f"• {topic}" for topic in topics_created])
                await message.answer(
                    f"✅ <b>Topics Creati con Successo!</b>\n\n"
                    f"📋 <b>Topics creati:</b>\n{topics_list}\n\n"
                    f"🎉 Il sistema è ora completamente operativo!",
                    parse_mode="HTML"
                )
            else:
                await message.answer(
                    "ℹ️ Tutti i topics sono già stati creati!\n\n"
                    "📦 Ordini ✅\n"
                    "📜 Sponsor ✅\n" 
                    "📝 Candidature ✅",
                    parse_mode="HTML"
                )
                
        except Exception as e:
            await message.answer(
                f"❌ Errore nella creazione dei topics: {str(e)}\n\n"
                f"💡 Assicurati che:\n"
                f"• Il bot sia admin del gruppo\n"
                f"• I Topics siano abilitati\n"
                f"• Il gruppo sia un supergruppo"
            )

    @router.message(Command("modifica_menu"))
    async def modify_menu_command(message: Message):
        """Handle /modifica_menu command"""
        if not is_admin(message.from_user.id):
            await message.answer("❌ Solo gli admin possono modificare il menù!")
            return
        
        menu_data = db.get_menu()
        categories = db.get_categories()
        
        keyboard = create_menu_edit_keyboard(categories)
        
        menu_text = "⚙️ <b>Modifica Menù</b>\n\n"
        menu_text += "📋 <b>Categorie disponibili:</b>\n"
        
        for category in categories:
            items = db.get_category_items(category)
            menu_text += f"\n{category}:\n"
            for item_name, item_data in items.items():
                menu_text += f"  • {item_name} - {item_data['price']}€\n"
        
        menu_text += "\n🔧 Seleziona un'azione:"
        
        await message.answer(
            menu_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )

    @router.message(Command("aggiungi_piatto"))
    async def add_dish_command(message: Message, state: FSMContext):
        """Handle /aggiungi_piatto command"""
        if not is_admin(message.from_user.id):
            await message.answer("❌ Solo gli admin possono aggiungere piatti!")
            return
        
        categories = db.get_categories()
        categories_text = "\n".join([f"• {cat}" for cat in categories])
        
        await message.answer(
            f"➕ <b>Aggiungi Nuovo Piatto</b>\n\n"
            f"📋 <b>Categorie disponibili:</b>\n{categories_text}\n\n"
            f"🏷️ Scrivi il nome della <b>categoria</b> (o creane una nuova):",
            parse_mode="HTML"
        )
        
        await state.set_state(AdminStates.waiting_for_category)

    @router.message(AdminStates.waiting_for_category)
    async def process_category(message: Message, state: FSMContext):
        """Process category input"""
        category = message.text.strip()
        
        if len(category) < 2 or len(category) > 30:
            await message.answer(
                "❌ Il nome della categoria deve essere tra 2 e 30 caratteri.\n"
                "🔄 Riprova:"
            )
            return
        
        await state.update_data(category=category)
        await message.answer(
            f"✅ Categoria: <b>{category}</b>\n\n"
            f"🍽️ Ora scrivi il <b>nome del piatto</b>:",
            parse_mode="HTML"
        )
        
        await state.set_state(AdminStates.waiting_for_item_name)

    @router.message(AdminStates.waiting_for_item_name)
    async def process_item_name(message: Message, state: FSMContext):
        """Process item name input"""
        item_name = message.text.strip()
        
        if len(item_name) < 2 or len(item_name) > 50:
            await message.answer(
                "❌ Il nome del piatto deve essere tra 2 e 50 caratteri.\n"
                "🔄 Riprova:"
            )
            return
        
        await state.update_data(item_name=item_name)
        await message.answer(
            f"✅ Piatto: <b>{item_name}</b>\n\n"
            f"💰 Ora scrivi il <b>prezzo in euro</b> (solo numero):",
            parse_mode="HTML"
        )
        
        await state.set_state(AdminStates.waiting_for_item_price)

    @router.message(AdminStates.waiting_for_item_price)
    async def process_item_price(message: Message, state: FSMContext):
        """Process item price input"""
        try:
            price = int(message.text.strip())
            if price < 1 or price > 9999:
                await message.answer(
                    "❌ Il prezzo deve essere tra 1 e 9999 euro.\n"
                    "🔄 Riprova:"
                )
                return
        except ValueError:
            await message.answer(
                "❌ Il prezzo deve essere un numero valido.\n"
                "🔄 Riprova:"
            )
            return
        
        await state.update_data(price=price)
        await message.answer(
            f"✅ Prezzo: <b>{price}€</b>\n\n"
            f"📝 Infine, scrivi una <b>descrizione</b> del piatto:",
            parse_mode="HTML"
        )
        
        await state.set_state(AdminStates.waiting_for_item_description)

    @router.message(Command("gestisci_menu"))
    async def manage_menu_command(message: Message):
        """Handle /gestisci_menu command"""
        user_id = message.from_user.id
        
        if user_id not in ADMIN_IDS:
            await message.reply("❌ Non hai i permessi per usare questo comando.")
            return
        
        keyboard = create_admin_menu_keyboard(db)
        await message.reply(
            "⚙️ <b>Gestione Menù</b>\n\n"
            "Scegli cosa vuoi fare:",
            reply_markup=keyboard,
            parse_mode="HTML"
        )

    @router.callback_query(lambda c: c.data == "add_menu_item")
    async def add_menu_item_callback(callback: CallbackQuery, state: FSMContext):
        """Start adding new menu item"""
        categories = db.get_categories()
        categories_text = "\n".join([f"• {cat}" for cat in categories])
        
        await callback.message.edit_text(
            f"➕ <b>Aggiungi Nuovo Piatto</b>\n\n"
            f"📋 <b>Categorie disponibili:</b>\n{categories_text}\n\n"
            f"🏷️ Scrivi il nome della <b>categoria</b> (o creane una nuova):",
            parse_mode="HTML"
        )
        await state.set_state(AdminStates.waiting_for_category)
        await callback.answer()

    @router.callback_query(lambda c: c.data == "remove_menu_item") 
    async def remove_menu_item_callback(callback: CallbackQuery):
        """Show menu items for removal"""
        categories = db.get_categories()
        keyboard = InlineKeyboardBuilder()
        
        for category in categories:
            items = db.get_category_items(category)
            for item_name in items:
                keyboard.add(InlineKeyboardButton(
                    text=f"❌ {item_name}",
                    callback_data=f"delete_item:{category}:{item_name}"
                ))
        
        keyboard.add(InlineKeyboardButton(
            text="🔙 Indietro",
            callback_data="back_to_admin_menu"
        ))
        
        keyboard.adjust(1)
        
        await callback.message.edit_text(
            "🗑️ <b>Rimuovi piatto</b>\n\n"
            "Seleziona il piatto da eliminare:",
            reply_markup=keyboard.as_markup(),
            parse_mode="HTML"
        )
        await callback.answer()

    @router.callback_query(lambda c: c.data.startswith("delete_item:"))
    async def delete_menu_item_callback(callback: CallbackQuery):
        """Delete menu item"""
        _, category, item_name = callback.data.split(":", 2)
        
        # Remove item from menu
        db.remove_menu_item(category, item_name)
        
        await callback.message.edit_text(
            f"✅ <b>Piatto rimosso!</b>\n\n"
            f"❌ <b>{item_name}</b> è stato eliminato dal menù.",
            parse_mode="HTML"
        )
        await callback.answer(f"{item_name} rimosso dal menù!")

    @router.callback_query(lambda c: c.data == "edit_menu_item")
    async def edit_menu_item_callback(callback: CallbackQuery):
        """Show menu items for editing"""
        categories = db.get_categories()
        keyboard = InlineKeyboardBuilder()
        
        for category in categories:
            items = db.get_category_items(category)
            for item_name, item_data in items.items():
                keyboard.add(InlineKeyboardButton(
                    text=f"✏️ {item_name} ({item_data['price']}€)",
                    callback_data=f"edit_item:{category}:{item_name}"
                ))
        
        keyboard.add(InlineKeyboardButton(
            text="🔙 Indietro",
            callback_data="back_to_admin_menu"
        ))
        
        keyboard.adjust(1)
        
        await callback.message.edit_text(
            "✏️ <b>Modifica piatto</b>\n\n"
            "Seleziona il piatto da modificare:",
            reply_markup=keyboard.as_markup(),
            parse_mode="HTML"
        )
        await callback.answer()

    @router.callback_query(lambda c: c.data.startswith("edit_item:"))
    async def edit_menu_item_start(callback: CallbackQuery, state: FSMContext):
        """Start editing menu item"""
        _, category, item_name = callback.data.split(":", 2)
        
        item = db.get_category_items(category)[item_name]
        
        await state.update_data(
            edit_category=category,
            edit_item_name=item_name,
            current_price=item['price']
        )
        
        await callback.message.edit_text(
            f"✏️ <b>Modifica: {item_name}</b>\n\n"
            f"💰 <b>Prezzo attuale:</b> {item['price']}€\n\n"
            f"📝 Scrivi il nuovo prezzo:",
            parse_mode="HTML"
        )
        
        await state.set_state(AdminStates.waiting_edit_price)
        await callback.answer()

    @router.callback_query(lambda c: c.data == "back_to_admin_menu")
    async def back_to_admin_menu_callback(callback: CallbackQuery):
        """Go back to admin menu"""
        keyboard = create_admin_menu_keyboard(db)
        await callback.message.edit_text(
            "⚙️ <b>Gestione Menù</b>\n\n"
            "Scegli cosa vuoi fare:",
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer()

    @router.message(AdminStates.waiting_edit_price)
    async def process_edit_price(message: Message, state: FSMContext):
        """Process price editing"""
        try:
            new_price = int(message.text.strip())
            if new_price < 1 or new_price > 9999:
                await message.answer(
                    "❌ Il prezzo deve essere tra 1 e 9999 euro.\n"
                    "🔄 Riprova:"
                )
                return
        except ValueError:
            await message.answer(
                "❌ Il prezzo deve essere un numero valido.\n"
                "🔄 Riprova:"
            )
            return
        
        # Get edit data
        data = await state.get_data()
        category = data.get("edit_category")
        item_name = data.get("edit_item_name")
        old_price = data.get("current_price")
        
        # Update item price
        db.update_menu_item_price(category, item_name, new_price)
        
        await message.answer(
            f"✅ <b>Prezzo aggiornato!</b>\n\n"
            f"🍽️ <b>Piatto:</b> {item_name}\n"
            f"💰 <b>Vecchio prezzo:</b> {old_price}€\n"
            f"💰 <b>Nuovo prezzo:</b> {new_price}€\n\n"
            f"🎉 Il menù è stato aggiornato!",
            parse_mode="HTML"
        )
        
        await state.clear()

    @router.message(AdminStates.waiting_for_item_description)
    async def process_item_description(message: Message, state: FSMContext):
        """Process item description and save item"""
        description = message.text.strip()
        
        if len(description) < 5 or len(description) > 200:
            await message.answer(
                "❌ La descrizione deve essere tra 5 e 200 caratteri.\n"
                "🔄 Riprova:"
            )
            return
        
        # Get all data
        data = await state.get_data()
        category = data.get("category")
        item_name = data.get("item_name")
        price = data.get("price")
        
        try:
            # Add item to menu
            db.add_menu_item(category, item_name, price, description)
            
            await message.answer(
                f"🎉 <b>Piatto Aggiunto con Successo!</b>\n\n"
                f"📋 <b>Riepilogo:</b>\n"
                f"🏷️ <b>Categoria:</b> {category}\n"
                f"🍽️ <b>Nome:</b> {item_name}\n"
                f"💰 <b>Prezzo:</b> {price}€\n"
                f"📝 <b>Descrizione:</b> {description}\n\n"
                f"✅ Il piatto è ora disponibile nel menù!",
                parse_mode="HTML"
            )
            
            # Clear state
            await state.clear()
            
        except Exception as e:
            await message.answer(
                f"❌ Errore nell'aggiungere il piatto: {str(e)}\n"
                f"🔄 Riprova più tardi."
            )
            await state.clear()

    @router.callback_query(lambda c: c.data.startswith("admin_menu:"))
    async def admin_menu_callback(callback: CallbackQuery):
        """Handle admin menu actions"""
        if not is_admin(callback.from_user.id):
            await callback.answer("❌ Solo gli admin possono usare questa funzione!", show_alert=True)
            return
        
        action = callback.data.split(":", 1)[1]
        
        if action == "view_stats":
            # Show statistics
            config = db.config
            
            total_orders = len(config.get("orders", {}))
            pending_orders = len([o for o in config.get("orders", {}).values() if o.get("status") == "pending"])
            total_sponsors = len(config.get("sponsors", {}))
            pending_sponsors = len([s for s in config.get("sponsors", {}).values() if s.get("status") == "pending"])
            total_applications = len(config.get("applications", {}))
            pending_applications = len([a for a in config.get("applications", {}).values() if a.get("status") == "pending"])
            
            stats_text = f"""
📊 <b>Statistiche {db.config.get('restaurant_name', 'The Krusty Krab')}</b>

📦 <b>Ordini:</b>
• Totali: {total_orders}
• In attesa: {pending_orders}

📣 <b>Sponsor:</b>
• Totali: {total_sponsors}  
• In attesa: {pending_sponsors}

📝 <b>Candidature:</b>
• Totali: {total_applications}
• In attesa: {pending_applications}

🏢 <b>Gruppo Staff:</b> {db.get_staff_group_id() or "Non configurato"}

⚡ <b>Sistema:</b> Operativo
            """
            
            await callback.message.edit_text(
                stats_text,
                parse_mode="HTML"
            )
            
        elif action == "backup":
            # Create backup (simplified)
            backup_text = f"""
💾 <b>Backup Sistema</b>

✅ Backup creato con successo!

📋 <b>Dati salvati:</b>
• Configurazione bot
• Menù completo  
• Ordini attivi
• Richieste sponsor
• Candidature

🕐 <b>Data backup:</b> {db.config.get("last_backup", "Mai")}
            """
            
            await callback.message.edit_text(
                backup_text,
                parse_mode="HTML"
            )
        
        await callback.answer()

    dp.include_router(router)
