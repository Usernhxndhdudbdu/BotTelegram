from aiogram import Router, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database import Database
from utils.keyboards import create_sponsor_request_keyboard, create_staff_sponsor_keyboard
from utils.messages import format_sponsor_message, format_staff_sponsor_message
from config import EMOJI, RESTAURANT_NAME

def register_handlers(dp, db: Database, bot: Bot):
    router = Router()

    @router.message(Command("sponsor"))
    async def sponsor_command(message: Message):
        """Handle /sponsor command"""
        keyboard = create_sponsor_request_keyboard()
        sponsor_text = f"""
📣 <b>Richiesta Sponsor - {RESTAURANT_NAME}</b>

🌟 Vuoi diventare uno sponsor ufficiale del nostro ristorante?

✨ <b>Cosa offriamo:</b>
• 🎯 Visibilità nel nostro locale
• 📢 Annunci personalizzati
• 🏆 Status di sponsor ufficiale
• 🎭 Esperienza roleplay unica

💡 <b>Come funziona:</b>
• Tutto è puramente roleplay
• Nessun costo reale
• Solo divertimento e creatività

🚀 Clicca il bottone qui sotto per inviare la tua richiesta!
        """
        
        await message.answer(
            sponsor_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )

    @router.callback_query(lambda c: c.data == "start_sponsor_request")
    async def start_sponsor_request_callback(callback: CallbackQuery):
        """Start sponsor request process"""
        await callback.message.edit_text(
            f"📤 <b>Richiesta Sponsor</b>\n\n"
            f"💡 <b>Come inviare la richiesta sponsor:</b>\n\n"
            f"1. 📝 <b>Scrivi un messaggio</b> con la tua richiesta di sponsor\n"
            f"   Descrivi il tuo progetto e perché vuoi sponsorizzare\n\n"
            f"2. ✅ Il messaggio verrà inoltrato al nostro staff\n\n"
            f"📨 <b>Scrivi ora il tuo messaggio sponsor!</b>",
            parse_mode="HTML"
        )
        
        # Set user state to expect sponsor message
        db.set_user_state(callback.from_user.id, "waiting_sponsor_message")
        await callback.answer()

    @router.message(lambda message: db.get_user_state(message.from_user.id) and 
                   db.get_user_state(message.from_user.id).get("state") == "waiting_sponsor_message")
    async def handle_sponsor_message(message: Message, bot: Bot):
        """Handle sponsor message or photo"""
        try:
            user = message.from_user
            username = f"@{user.username}" if user.username else f"{user.first_name}"
            
            # Create sponsor request with message/photo
            sponsor_id = db.create_sponsor_request(user.id, username)
            
            # Store the message content
            sponsor_data = db.get_sponsor_request(sponsor_id)
            if message.photo:
                sponsor_data["content_type"] = "photo"
                sponsor_data["photo_file_id"] = message.photo[-1].file_id
                sponsor_data["caption"] = message.caption or ""
            else:
                sponsor_data["content_type"] = "text"
                sponsor_data["message_text"] = message.text
            
            # Update sponsor data
            db.config["sponsors"][sponsor_id] = sponsor_data
            db.save_config()
            
            # Clear user state
            db.clear_user_state(user.id)
            
            # Confirm to user and ask for payment proof
            await message.reply(
                f"📣 <b>Richiesta Sponsor Inviata!</b>\n\n"
                f"✅ La tua richiesta è stata inviata al nostro team!\n"
                f"📋 <b>ID Richiesta:</b> <code>{sponsor_id}</code>\n\n"
                f"📷 <b>IMPORTANTE:</b> Ora devi inviare una foto che mostra il pagamento effettuato.\n"
                f"Invia lo screenshot del pagamento per completare la richiesta.",
                parse_mode="HTML"
            )
            
            # Set state for payment photo
            db.set_user_state(user.id, "waiting_payment_photo", {"sponsor_id": sponsor_id})
            
            # Send to staff group
            staff_group_id = db.get_staff_group_id()
            sponsors_topic_id = db.get_topic_id("sponsors")
            
            if staff_group_id and sponsors_topic_id:
                keyboard = create_staff_sponsor_keyboard(sponsor_id)
                
                # Send original message/photo to staff
                if message.photo:
                    staff_msg = await bot.send_photo(
                        chat_id=staff_group_id,
                        message_thread_id=sponsors_topic_id,
                        photo=message.photo[-1].file_id,
                        caption=format_staff_sponsor_message(sponsor_id, username) + 
                               (f"\n\n📝 <b>Didascalia:</b> {message.caption}" if message.caption else ""),
                        reply_markup=keyboard,
                        parse_mode="HTML"
                    )
                else:
                    staff_message = format_staff_sponsor_message(sponsor_id, username)
                    staff_message += f"\n\n💬 <b>Messaggio:</b>\n<i>{message.text}</i>"
                    
                    staff_msg = await bot.send_message(
                        chat_id=staff_group_id,
                        message_thread_id=sponsors_topic_id,
                        text=staff_message,
                        reply_markup=keyboard,
                        parse_mode="HTML"
                    )
                
                # Save staff message ID
                db.set_sponsor_staff_message(sponsor_id, staff_msg.message_id)
            
        except Exception as e:
            await message.reply(
                "❌ Errore nell'invio della richiesta sponsor. Riprova più tardi."
            )
            db.clear_user_state(user.id)

    @router.message(lambda message: db.get_user_state(message.from_user.id) and 
                   db.get_user_state(message.from_user.id).get("state") == "waiting_payment_photo")
    async def handle_payment_photo(message: Message, bot: Bot):
        """Handle payment photo for sponsor request"""
        try:
            user = message.from_user
            user_state = db.get_user_state(user.id)
            sponsor_id = user_state["data"]["sponsor_id"]
            
            if not message.photo:
                await message.reply("📷 Devi inviare una foto del pagamento, non un testo!")
                return
            
            # Update sponsor with payment photo
            sponsor_data = db.get_sponsor_request(sponsor_id)
            sponsor_data["payment_photo_file_id"] = message.photo[-1].file_id
            sponsor_data["payment_caption"] = message.caption or ""
            sponsor_data["status"] = "payment_received"
            
            # Save updated data
            db.config["sponsors"][sponsor_id] = sponsor_data
            db.save_config()
            
            # Clear user state
            db.clear_user_state(user.id)
            
            # Send confirmation
            await message.reply(
                f"✅ <b>Pagamento ricevuto!</b>\n\n"
                f"📷 Screenshot del pagamento confermato\n"
                f"📋 <b>ID Richiesta:</b> <code>{sponsor_id}</code>\n\n"
                f"⏳ La richiesta è ora completa e sarà processata dal team!",
                parse_mode="HTML"
            )
            
            # Send to sponsor channel (if configured)
            sponsor_channel_id = db.config.get("sponsor_channel_id")
            if sponsor_channel_id:
                try:
                    await bot.send_photo(
                        chat_id=sponsor_channel_id,
                        photo=message.photo[-1].file_id,
                        caption=f"📣 <b>Nuova Richiesta Sponsor</b>\n\n"
                               f"👤 <b>Da:</b> {sponsor_data['username']}\n"
                               f"📋 <b>ID:</b> <code>{sponsor_id}</code>\n"
                               f"💬 <b>Messaggio:</b> {sponsor_data.get('message_text', 'N/A')}\n\n"
                               f"📷 <b>Prova di pagamento allegata</b>",
                        parse_mode="HTML"
                    )
                except Exception as e:
                    # If channel not accessible, continue silently
                    pass
            
        except Exception as e:
            await message.reply("❌ Errore nel processare la foto del pagamento.")
            db.clear_user_state(user.id)

    @router.callback_query(lambda c: c.data.startswith("staff_sponsor:"))
    async def staff_sponsor_callback(callback: CallbackQuery, bot: Bot):
        """Handle staff sponsor actions"""
        try:
            parts = callback.data.split(":", 2)
            action = parts[1]
            sponsor_id = parts[2]
            
            sponsor = db.get_sponsor_request(sponsor_id)
            if not sponsor:
                await callback.answer("Richiesta sponsor non trovata!", show_alert=True)
                return
            
            staff_user = callback.from_user
            staff_name = f"@{staff_user.username}" if staff_user.username else staff_user.first_name
            
            if action == "approve":
                # Approve sponsor
                db.update_sponsor_status(sponsor_id, "approved")
                
                # Update staff message
                updated_message = format_staff_sponsor_message(sponsor_id, sponsor["username"], "approved", staff_name)
                
                await callback.message.edit_text(
                    updated_message,
                    parse_mode="HTML"
                )
                
                # Notify user
                await bot.send_message(
                    chat_id=sponsor["user_id"],
                    text=f"🎉 <b>Richiesta Sponsor Approvata!</b>\n\n"
                         f"✅ Congratulazioni! La tua richiesta è stata accettata da {staff_name}!\n"
                         f"🌟 Sei ora uno sponsor ufficiale di {RESTAURANT_NAME}!\n\n"
                         f"📢 Ti contatteremo presto con i dettagli per il tuo annuncio!\n"
                         f"🎭 Benvenuto nella famiglia Krusty Krab! 🦀",
                    parse_mode="HTML"
                )
                
                await callback.answer("Richiesta sponsor approvata!")
                
            elif action == "reject":
                # Reject sponsor
                db.update_sponsor_status(sponsor_id, "rejected")
                
                # Update staff message
                updated_message = format_staff_sponsor_message(sponsor_id, sponsor["username"], "rejected", staff_name)
                
                await callback.message.edit_text(
                    updated_message,
                    parse_mode="HTML"
                )
                
                # Notify user
                await bot.send_message(
                    chat_id=sponsor["user_id"],
                    text=f"😔 <b>Richiesta Sponsor Rifiutata</b>\n\n"
                         f"❌ Spiacenti, la tua richiesta non può essere accettata al momento.\n"
                         f"💡 Puoi riprovare più tardi o contattare lo staff per maggiori informazioni.\n\n"
                         f"🙏 Grazie per l'interesse in {RESTAURANT_NAME}!",
                    parse_mode="HTML"
                )
                
                await callback.answer("Richiesta sponsor rifiutata!")
                
        except Exception as e:
            await callback.answer("Errore nell'elaborazione!", show_alert=True)

    dp.include_router(router)
