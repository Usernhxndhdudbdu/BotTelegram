from aiogram import Router, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database import Database
from utils.keyboards import create_menu_keyboard, create_category_keyboard
from utils.messages import format_menu_message, format_category_message
from config import WELCOME_MESSAGE

def register_handlers(dp, db: Database, bot: Bot):
    router = Router()

    @router.message(Command("start"))
    async def start_command(message: Message):
        """Handle /start command"""
        await message.answer(
            WELCOME_MESSAGE,
            parse_mode="HTML"
        )

    @router.message(Command("menu"))
    async def menu_command(message: Message):
        """Handle /menu command"""
        keyboard = create_menu_keyboard(db)
        await message.answer(
            format_menu_message(),
            reply_markup=keyboard,
            parse_mode="HTML"
        )

    @router.callback_query(lambda c: c.data.startswith("menu_category:"))
    async def category_callback(callback: CallbackQuery):
        """Handle category selection"""
        category = callback.data.split(":", 1)[1]
        items = db.get_category_items(category)
        
        if not items:
            await callback.answer("Categoria vuota!", show_alert=True)
            return
        
        keyboard = create_category_keyboard(category, items, db, callback.from_user.id)
        message_text = format_category_message(category, items)
        
        await callback.message.edit_text(
            message_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer()

    @router.callback_query(lambda c: c.data.startswith("add_to_cart:"))
    async def add_to_cart_callback(callback: CallbackQuery):
        """Handle add to cart action"""
        try:
            parts = callback.data.split(":", 2)
            category = parts[1]
            item_name = parts[2]
            
            items = db.get_category_items(category)
            if item_name not in items:
                await callback.answer("Prodotto non disponibile!", show_alert=True)
                return
            
            item = items[item_name]
            db.add_to_cart(callback.from_user.id, item_name, item["price"], category)
            
            # Update keyboard to show new cart count
            keyboard = create_category_keyboard(category, items, db, callback.from_user.id)
            
            await callback.message.edit_reply_markup(reply_markup=keyboard)
            await callback.answer(f"✅ {item_name} aggiunto al carrello!")
            
        except Exception as e:
            await callback.answer("Errore nell'aggiungere al carrello!", show_alert=True)

    @router.callback_query(lambda c: c.data == "view_cart")
    async def view_cart_callback(callback: CallbackQuery):
        """Handle view cart action"""
        from utils.messages import format_cart_message
        from utils.keyboards import create_cart_keyboard
        
        keyboard = create_cart_keyboard(db, callback.from_user.id)
        message_text = format_cart_message(db, callback.from_user.id)
        
        await callback.message.edit_text(
            message_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer()

    @router.callback_query(lambda c: c.data.startswith("remove_from_cart:"))
    async def remove_from_cart_callback(callback: CallbackQuery):
        """Handle remove from cart action"""
        item_name = callback.data.split(":", 1)[1]
        db.remove_from_cart(callback.from_user.id, item_name)
        
        from utils.messages import format_cart_message
        from utils.keyboards import create_cart_keyboard
        
        keyboard = create_cart_keyboard(db, callback.from_user.id)
        message_text = format_cart_message(db, callback.from_user.id)
        
        await callback.message.edit_text(
            message_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer(f"❌ {item_name} rimosso dal carrello!")

    @router.callback_query(lambda c: c.data == "clear_cart")
    async def clear_cart_callback(callback: CallbackQuery):
        """Handle clear cart action"""
        db.clear_cart(callback.from_user.id)
        
        from utils.messages import format_cart_message
        from utils.keyboards import create_cart_keyboard
        
        keyboard = create_cart_keyboard(db, callback.from_user.id)
        message_text = format_cart_message(db, callback.from_user.id)
        
        await callback.message.edit_text(
            message_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer("🗑️ Carrello svuotato!")

    @router.callback_query(lambda c: c.data == "confirm_cart_order")
    async def confirm_cart_order_callback(callback: CallbackQuery, bot: Bot):
        """Handle cart order confirmation"""
        try:
            user = callback.from_user
            username = f"@{user.username}" if user.username else f"{user.first_name}"
            
            cart = db.get_user_cart(user.id)
            if not cart:
                await callback.answer("Carrello vuoto!", show_alert=True)
                return
            
            # Create order from cart
            order_id = db.create_order_from_cart(user.id, username)
            if not order_id:
                await callback.answer("Errore nella creazione dell'ordine!", show_alert=True)
                return
            
            order = db.get_order(order_id)
            
            # Create order summary for user
            order_summary = "🎉 <b>Ordine confermato!</b>\n\n"
            order_summary += "📦 <b>Prodotti ordinati:</b>\n"
            
            for item in order["items"]:
                quantity = item.get("quantity", 1)
                order_summary += f"• {item['item_name']} x{quantity} - {item['item_price'] * quantity}€\n"
            
            order_summary += f"\n💰 <b>Totale:</b> {order['total_price']}€\n"
            order_summary += f"📋 <b>ID Ordine:</b> <code>{order_id}</code>\n\n"
            order_summary += "⏳ Il tuo ordine è stato inviato allo staff!\nTi avviseremo quando sarà pronto! 🍽️"
            
            # Send confirmation to user and ask for payment photo
            await callback.message.edit_text(
                order_summary + f"\n\n📷 <b>IMPORTANTE:</b> Ora devi inviare una foto che mostra il pagamento effettuato per completare l'ordine.",
                parse_mode="HTML"
            )
            
            # Set state for payment photo
            db.set_user_state(callback.from_user.id, "waiting_order_payment_photo", {"order_id": order_id})
            
            # Send order to staff group
            staff_group_id = db.get_staff_group_id()
            orders_topic_id = db.get_topic_id("orders")
            
            if staff_group_id and orders_topic_id:
                from utils.keyboards import create_staff_order_keyboard
                from utils.messages import format_staff_order_message
                
                keyboard = create_staff_order_keyboard(order_id)
                staff_message = format_staff_order_message(order)
                
                staff_msg = await bot.send_message(
                    chat_id=staff_group_id,
                    message_thread_id=orders_topic_id,
                    text=staff_message,
                    reply_markup=keyboard,
                    parse_mode="HTML"
                )
                
                # Save staff message ID
                db.set_order_staff_message(order_id, staff_msg.message_id)
            
            await callback.answer("Ordine inviato con successo!")
            
        except Exception as e:
            await callback.answer("Errore nella conferma dell'ordine!", show_alert=True)

    @router.message(lambda message: db.get_user_state(message.from_user.id) and 
                   db.get_user_state(message.from_user.id).get("state") == "waiting_order_payment_photo")
    async def handle_order_payment_photo(message: Message, bot: Bot):
        """Handle payment photo for order"""
        try:
            user = message.from_user
            user_state = db.get_user_state(user.id)
            order_id = user_state["data"]["order_id"]
            
            if not message.photo:
                await message.reply("📷 Devi inviare una foto del pagamento, non un testo!")
                return
            
            # Update order with payment photo
            order = db.get_order(order_id)
            if order:
                order["payment_photo_file_id"] = message.photo[-1].file_id
                order["payment_caption"] = message.caption or ""
                order["payment_status"] = "received"
                
                # Save updated order
                db.config["orders"][order_id] = order
                db.save_config()
            
            # Clear user state  
            db.clear_user_state(user.id)
            
            # Send final confirmation
            await message.reply(
                f"✅ <b>Ordine completato!</b>\n\n"
                f"📷 Pagamento ricevuto e confermato\n"
                f"📋 <b>ID Ordine:</b> <code>{order_id}</code>\n\n"
                f"🔥 Il tuo ordine è ora in coda per la preparazione!",
                parse_mode="HTML"
            )
            
            # Now send to staff group
            staff_group_id = db.get_staff_group_id()
            orders_topic_id = db.get_topic_id("orders")
            
            if staff_group_id and orders_topic_id and order:
                from utils.keyboards import create_staff_order_keyboard
                from utils.messages import format_staff_order_message
                
                keyboard = create_staff_order_keyboard(order_id)
                staff_message = format_staff_order_message(order)
                
                # Add payment info to staff message
                staff_message += f"\n💳 <b>Pagamento:</b> ✅ Ricevuto"
                
                staff_msg = await bot.send_message(
                    chat_id=staff_group_id,
                    message_thread_id=orders_topic_id,
                    text=staff_message,
                    reply_markup=keyboard,
                    parse_mode="HTML"
                )
                
                # Save staff message ID
                db.set_order_staff_message(order_id, staff_msg.message_id)
                
        except Exception as e:
            await message.reply("❌ Errore nel processare la foto del pagamento.")
            db.clear_user_state(user.id)

    @router.callback_query(lambda c: c.data == "menu_back")
    async def menu_back_callback(callback: CallbackQuery):
        """Handle back to main menu"""
        keyboard = create_menu_keyboard(db)
        await callback.message.edit_text(
            format_menu_message(),
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer()

    dp.include_router(router)
