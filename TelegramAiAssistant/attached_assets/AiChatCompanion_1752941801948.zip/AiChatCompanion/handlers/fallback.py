from aiogram import Router, Bot
from aiogram.types import Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton

from database import Database
from config import RESTAURANT_NAME
from utils.keyboards import create_menu_keyboard

def register_handlers(dp, db: Database, bot: Bot):
    router = Router()

    @router.message()
    async def handle_unknown_message(message: Message):
        """Handle all unrecognized messages"""
        
        # Check if user is in a special state (waiting for sponsor message, etc)
        user_state = db.get_user_state(message.from_user.id)
        if user_state:
            # Let the specific handler deal with it
            return
        
        # Create helpful response with quick actions
        keyboard = InlineKeyboardBuilder()
        
        keyboard.add(InlineKeyboardButton(
            text="🍔 Vai al Menù",
            callback_data="goto_menu"
        ))
        
        keyboard.add(InlineKeyboardButton(
            text="📣 Richiedi Sponsor", 
            callback_data="start_sponsor_request"
        ))
        
        keyboard.add(InlineKeyboardButton(
            text="📝 Invia Curriculum",
            callback_data="start_application"
        ))
        
        keyboard.adjust(1)
        
        response_text = f"""
🤔 <b>Non ho capito il tuo messaggio!</b>

💡 <b>Ecco cosa puoi fare:</b>
• Usa i bottoni qui sotto per azioni rapide
• Oppure usa i comandi:
  /menu - Visualizza il menù
  /sponsor - Richiedi sponsor
  /curriculum - Candidati per lavorare

🦀 <i>Benvenuto al {RESTAURANT_NAME}!</i>
        """
        
        await message.reply(
            response_text,
            reply_markup=keyboard.as_markup(),
            parse_mode="HTML"
        )

    @router.callback_query(lambda c: c.data == "goto_menu")
    async def goto_menu_callback(callback):
        """Handle go to menu action"""
        from utils.messages import format_menu_message
        
        keyboard = create_menu_keyboard(db)
        await callback.message.edit_text(
            format_menu_message(),
            reply_markup=keyboard,
            parse_mode="HTML"
        )
        await callback.answer()

    # Register this router last so it catches unhandled messages
    dp.include_router(router)