from aiogram import Router, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database import Database
from utils.keyboards import create_order_confirmation_keyboard, create_staff_order_keyboard
from utils.messages import format_order_confirmation, format_staff_order_message
from config import EMOJI

def register_handlers(dp, db: Database, bot: Bot):
    router = Router()

    @router.callback_query(lambda c: c.data.startswith("order_item:"))
    async def order_item_callback(callback: CallbackQuery):
        """Handle item order request"""
        try:
            parts = callback.data.split(":", 2)
            category = parts[1]
            item_name = parts[2]
            
            items = db.get_category_items(category)
            if item_name not in items:
                await callback.answer("Prodotto non disponibile!", show_alert=True)
                return
            
            item = items[item_name]
            keyboard = create_order_confirmation_keyboard(category, item_name, item["price"])
            message_text = format_order_confirmation(item_name, item["price"], item["description"])
            
            await callback.message.edit_text(
                message_text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
            await callback.answer()
            
        except Exception as e:
            await callback.answer("Errore nel processare l'ordine!", show_alert=True)

    @router.callback_query(lambda c: c.data.startswith("confirm_order:"))
    async def confirm_order_callback(callback: CallbackQuery, bot: Bot):
        """Handle order confirmation"""
        try:
            parts = callback.data.split(":", 3)
            category = parts[1]
            item_name = parts[2]
            item_price = int(parts[3])
            
            user = callback.from_user
            username = f"@{user.username}" if user.username else f"{user.first_name}"
            
            # Create order in database
            order_id = db.create_order(user.id, username, item_name, item_price)
            
            # Send confirmation to user
            await callback.message.edit_text(
                f"🎉 <b>Ordine confermato!</b>\n\n"
                f"📦 <b>Prodotto:</b> {item_name}\n"
                f"💰 <b>Prezzo:</b> {item_price} crediti\n"
                f"📋 <b>ID Ordine:</b> <code>{order_id}</code>\n\n"
                f"⏳ Il tuo ordine è stato inviato allo staff!\n"
                f"Ti avviseremo quando sarà pronto! 🍽️",
                parse_mode="HTML"
            )
            
            # Send order to staff group
            staff_group_id = db.get_staff_group_id()
            orders_topic_id = db.get_topic_id("orders")
            
            if staff_group_id and orders_topic_id:
                keyboard = create_staff_order_keyboard(order_id)
                staff_message = format_staff_order_message(order_id, username, item_name, item_price)
                
                staff_msg = await bot.send_message(
                    chat_id=staff_group_id,
                    message_thread_id=orders_topic_id,
                    text=staff_message,
                    reply_markup=keyboard,
                    parse_mode="HTML"
                )
                
                # Save staff message ID
                db.set_order_staff_message(order_id, staff_msg.message_id)
            
            await callback.answer("Ordine inviato con successo!")
            
        except Exception as e:
            await callback.answer("Errore nella conferma dell'ordine!", show_alert=True)

    @router.callback_query(lambda c: c.data.startswith("staff_order:"))
    async def staff_order_callback(callback: CallbackQuery, bot: Bot):
        """Handle staff order actions"""
        try:
            parts = callback.data.split(":", 2)
            action = parts[1]
            order_id = parts[2]
            
            order = db.get_order(order_id)
            if not order:
                await callback.answer("Ordine non trovato!", show_alert=True)
                return
            
            staff_user = callback.from_user
            staff_name = f"@{staff_user.username}" if staff_user.username else staff_user.first_name
            
            if action == "take":
                # Take order
                db.update_order_status(order_id, "preparing", staff_user.id)
                
                # Update staff message
                updated_message = format_staff_order_message(order, "preparing", staff_name)
                keyboard = create_staff_order_keyboard(order_id, "preparing")
                
                await callback.message.edit_text(
                    updated_message,
                    reply_markup=keyboard,
                    parse_mode="HTML"
                )
                
                # Notify customer - handle both cart and single item orders
                order_description = ""
                if "items" in order and len(order["items"]) > 1:
                    order_description = f"il tuo ordine (#{order_id[-8:]})"
                elif "items" in order:
                    order_description = f"<b>{order['items'][0]['item_name']}</b>"
                else:
                    order_description = f"<b>{order.get('item_name', 'il tuo ordine')}</b>"
                
                await bot.send_message(
                    chat_id=order["user_id"],
                    text=f"🔥 <b>Il tuo ordine è in preparazione!</b>\n\n"
                         f"📦 {order_description} è ora nelle mani esperte del nostro chef {staff_name}!\n"
                         f"⏱️ Ti avviseremo quando sarà pronto! 🍽️",
                    parse_mode="HTML"
                )
                
                await callback.answer(f"Ordine preso in carico da {staff_name}!")
                
            elif action == "ready":
                # Mark as ready
                db.update_order_status(order_id, "ready")
                
                # Update staff message
                updated_message = format_staff_order_message(order, "ready", staff_name)
                keyboard = create_staff_order_keyboard(order_id, "ready")
                
                await callback.message.edit_text(
                    updated_message,
                    reply_markup=keyboard,
                    parse_mode="HTML"
                )
                
                # Notify customer - handle both cart and single item orders  
                if "items" in order and len(order["items"]) > 1:
                    order_description = f"il tuo ordine (#{order_id[-8:]})"
                elif "items" in order:
                    order_description = f"<b>{order['items'][0]['item_name']}</b>"
                else:
                    order_description = f"<b>{order.get('item_name', 'il tuo ordine')}</b>"
                
                await bot.send_message(
                    chat_id=order["user_id"],
                    text=f"🎉 <b>Il tuo ordine è pronto!</b>\n\n"
                         f"📦 {order_description} ti aspetta al bancone!\n"
                         f"🏃‍♂️ Vieni a ritirarlo quando vuoi! ✨",
                    parse_mode="HTML"
                )
                
                await callback.answer("Ordine segnato come pronto!")
                
            elif action == "reject":
                # Reject order
                db.update_order_status(order_id, "rejected")
                
                # Update staff message
                updated_message = format_staff_order_message(order, "rejected", staff_name)
                
                await callback.message.edit_text(
                    updated_message,
                    parse_mode="HTML"
                )
                
                # Notify customer - handle both cart and single item orders
                if "items" in order and len(order["items"]) > 1:
                    order_description = f"il tuo ordine (#{order_id[-8:]})"
                elif "items" in order:
                    order_description = f"<b>{order['items'][0]['item_name']}</b>"
                else:
                    order_description = f"<b>{order.get('item_name', 'il tuo ordine')}</b>"
                
                await bot.send_message(
                    chat_id=order["user_id"],
                    text=f"😔 <b>Spiacenti, ordine rifiutato</b>\n\n"
                         f"📦 {order_description} non può essere preparato in questo momento.\n"
                         f"💝 Prova più tardi o scegli un altro prodotto! 🍽️",
                    parse_mode="HTML"
                )
                
                await callback.answer("Ordine rifiutato!")
                
        except Exception as e:
            await callback.answer("Errore nell'elaborazione!", show_alert=True)

    dp.include_router(router)
