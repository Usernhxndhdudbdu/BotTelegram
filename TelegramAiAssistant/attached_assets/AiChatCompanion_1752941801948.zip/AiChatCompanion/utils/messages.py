from typing import Dict, Optional
from config import RESTAURANT_NAME, EMOJI

def format_menu_message() -> str:
    """Format main menu message"""
    return f"""
🦀 <b>{RESTAURANT_NAME}</b> 🦀

🍽️ <b>Benvenuto nel nostro delizioso menù!</b>

✨ Scegli una categoria per vedere i nostri prodotti speciali:

🎯 <b>Che cosa desideri fare?</b>
• 🍔 Ordinare del cibo delizioso
• 📣 Richiedere uno sponsor
• 📝 Candidarti per lavorare con noi

<i>Tutto è puramente roleplay e divertimento! 🎭</i>
    """

def format_category_message(category: str, items: Dict) -> str:
    """Format category items message"""
    message = f"🍽️ <b>{category}</b>\n\n"
    message += "🎯 <b>Prodotti disponibili:</b>\n\n"
    
    for item_name, item_data in items.items():
        message += f"🔸 <b>{item_name}</b>\n"
        message += f"   💰 {item_data['price']} crediti\n"
        message += f"   📝 {item_data['description']}\n\n"
    
    message += "👆 <i>Clicca su un prodotto per ordinarlo!</i>"
    return message

def format_order_confirmation(item_name: str, price: int, description: str) -> str:
    """Format order confirmation message"""
    return f"""
🛒 <b>Conferma il tuo ordine</b>

🍽️ <b>Prodotto:</b> {item_name}
💰 <b>Prezzo:</b> {price} crediti
📝 <b>Descrizione:</b> {description}

❓ <b>Vuoi confermare questo ordine?</b>

⚡ <i>L'ordine verrà inviato immediatamente al nostro staff!</i>
    """

def format_cart_message(db, user_id: int) -> str:
    """Format shopping cart message"""
    cart = db.get_user_cart(user_id)
    
    if not cart:
        return """
🛒 <b>Il tuo carrello è vuoto!</b>

💡 Vai al menù per aggiungere prodotti deliziosi al Krusty Krab!
🦀 Usa i bottoni qui sotto per navigare.
        """
    
    message = "🛒 <b>Il tuo carrello:</b>\n\n"
    
    total_items = 0
    total_price = 0
    
    for item in cart:
        quantity = item.get('quantity', 1)
        item_total = item['item_price'] * quantity
        total_items += quantity
        total_price += item_total
        
        message += f"🔸 <b>{item['item_name']}</b>\n"
        message += f"   💰 {item['item_price']}€ × {quantity} = {item_total}€\n\n"
    
    message += f"📊 <b>Totale: {total_price}€ ({total_items} prodotti)</b>\n\n"
    message += "👆 <i>Clicca ❌ per rimuovere un prodotto o 📦 per ordinare tutto!</i>"
    
    return message

def format_staff_order_message(order, status: str = None, staff_name: Optional[str] = None) -> str:
    """Format staff order message"""
    
    status_emojis = {
        "pending": "⏳",
        "preparing": "🔥", 
        "ready": "✅",
        "rejected": "❌"
    }
    
    status_texts = {
        "pending": "In attesa",
        "preparing": "In preparazione", 
        "ready": "Pronto", 
        "rejected": "Rifiutato"
    }
    
    current_status = status or order.get("status", "pending")
    emoji = status_emojis.get(current_status, "❓")
    status_text = status_texts.get(current_status, "Sconosciuto")
    
    message = f"""
📦 <b>Ordine #{order['id'][-8:]}</b>

👤 <b>Cliente:</b> {order['username']}
"""
    
    # Handle both new cart orders and legacy single item orders
    if "items" in order:
        message += "🍽️ <b>Prodotti:</b>\n"
        for item in order["items"]:
            quantity = item.get("quantity", 1)
            message += f"  • {item['item_name']} x{quantity} - {item['item_price'] * quantity}€\n"
        message += f"\n💰 <b>Totale:</b> {order['total_price']}€\n"
    else:
        # Legacy format
        message += f"🍽️ <b>Prodotto:</b> {order.get('item_name', 'N/A')}\n"
        message += f"💰 <b>Prezzo:</b> {order.get('item_price', 0)}€\n"
    
    message += f"\n{emoji} <b>Stato:</b> {status_text}"
    
    if staff_name and current_status != "pending":
        message += f"\n👨‍🍳 <b>Gestito da:</b> {staff_name}"
    
    return message

def format_sponsor_message() -> str:
    """Format sponsor request message"""
    return f"""
📣 <b>Richiesta Sponsor - {RESTAURANT_NAME}</b>

🌟 Vuoi diventare uno sponsor ufficiale del nostro ristorante?

✨ <b>Cosa offriamo:</b>
• 🎯 Visibilità nel nostro locale
• 📢 Annunci personalizzati  
• 🏆 Status di sponsor ufficiale
• 🎭 Esperienza roleplay unica

💡 <b>Come funziona:</b>
• Tutto è puramente roleplay
• Nessun costo reale
• Solo divertimento e creatività

🚀 Clicca il bottone qui sotto per inviare la tua richiesta!
    """

def format_staff_sponsor_message(
    sponsor_id: str,
    username: str, 
    status: str = "pending",
    staff_name: Optional[str] = None
) -> str:
    """Format staff sponsor message"""
    
    status_emojis = {
        "pending": "⏳",
        "approved": "✅", 
        "rejected": "❌"
    }
    
    status_texts = {
        "pending": "In attesa",
        "approved": "Approvato",
        "rejected": "Rifiutato"
    }
    
    emoji = status_emojis.get(status, "❓")
    status_text = status_texts.get(status, "Sconosciuto")
    
    message = f"""
📣 <b>Richiesta Sponsor #{sponsor_id[-8:]}</b>

👤 <b>Da:</b> {username}
📋 <b>Tipo:</b> Sponsor generico (roleplay)

{emoji} <b>Stato:</b> {status_text}
    """
    
    if staff_name and status != "pending":
        message += f"\n👨‍💼 <b>Gestito da:</b> {staff_name}"
    
    return message

def format_application_message(name: str, age: str, role: str) -> str:
    """Format application confirmation message"""
    return f"""
📝 <b>Candidatura Inviata!</b>

✅ <b>I tuoi dati:</b>
🏷️ <b>Nome:</b> {name}
🎂 <b>Età:</b> {age} anni  
💼 <b>Ruolo:</b> {role}

⏳ <b>La tua candidatura è stata inviata al nostro team HR!</b>
📞 Ti contatteremo presto con la risposta!

🌟 <i>Grazie per l'interesse in {RESTAURANT_NAME}!</i>
    """

def format_staff_application_message(
    app_id: str,
    username: str,
    name: str,
    age: str, 
    role: str,
    status: str = "pending",
    staff_name: Optional[str] = None
) -> str:
    """Format staff application message"""
    
    status_emojis = {
        "pending": "⏳",
        "approved": "✅",
        "rejected": "❌"
    }
    
    status_texts = {
        "pending": "In attesa",
        "approved": "Approvato", 
        "rejected": "Rifiutato"
    }
    
    emoji = status_emojis.get(status, "❓")
    status_text = status_texts.get(status, "Sconosciuto")
    
    message = f"""
📝 <b>Candidatura #{app_id[-8:]}</b>

👤 <b>Telegram:</b> {username}
🏷️ <b>Nome RP:</b> {name}
🎂 <b>Età RP:</b> {age} anni
💼 <b>Ruolo richiesto:</b> {role}

{emoji} <b>Stato:</b> {status_text}
    """
    
    if staff_name and status != "pending":
        message += f"\n👨‍💼 <b>Gestito da:</b> {staff_name}"
    
    return message

def format_notification_message(message_type: str, details: Dict) -> str:
    """Format notification messages for users"""
    
    if message_type == "order_taken":
        return f"""
🔥 <b>Il tuo ordine è in preparazione!</b>

📦 <b>{details['item_name']}</b> è ora nelle mani esperte del nostro chef!
⏱️ Ti avviseremo quando sarà pronto! 🍽️
        """
    
    elif message_type == "order_ready":
        return f"""
🎉 <b>Il tuo ordine è pronto!</b>

📦 <b>{details['item_name']}</b> ti aspetta al bancone!
🏃‍♂️ Vieni a ritirarlo quando vuoi! ✨
        """
    
    elif message_type == "order_rejected":
        return f"""
😔 <b>Spiacenti, ordine rifiutato</b>

📦 <b>{details['item_name']}</b> non può essere preparato in questo momento.
💝 Prova più tardi o scegli un altro prodotto! 🍽️
        """
    
    elif message_type == "sponsor_approved":
        return f"""
🎉 <b>Richiesta Sponsor Approvata!</b>

✅ Congratulazioni! La tua richiesta è stata accettata!
🌟 Sei ora uno sponsor ufficiale di {RESTAURANT_NAME}!

📢 Ti contatteremo presto con i dettagli per il tuo annuncio!
🎭 Benvenuto nella famiglia Krusty Krab! 🦀
        """
    
    elif message_type == "sponsor_rejected":
        return f"""
😔 <b>Richiesta Sponsor Rifiutata</b>

❌ Spiacenti, la tua richiesta non può essere accettata al momento.
💡 Puoi riprovare più tardi o contattare lo staff per maggiori informazioni.

🙏 Grazie per l'interesse in {RESTAURANT_NAME}!
        """
    
    elif message_type == "application_approved":
        return f"""
🎉 <b>Candidatura Approvata!</b>

✅ Congratulazioni {details['name']}!
🎊 La tua candidatura per <b>{details['role']}</b> è stata accettata!

🏢 Benvenuto nel team di {RESTAURANT_NAME}!
📞 Ti contatteremo presto per i dettagli!

🦀 Preparati a vivere l'avventura Krusty Krab! ✨
        """
    
    elif message_type == "application_rejected":
        return f"""
😔 <b>Candidatura Non Accettata</b>

❌ Spiacenti {details['name']}, la tua candidatura per <b>{details['role']}</b> non può essere accettata al momento.

💡 Non scoraggiarti! Puoi riprovare in futuro o candidarti per altri ruoli.
🙏 Grazie per l'interesse in {RESTAURANT_NAME}!

🌊 Il mare è pieno di opportunità! 🐠
        """
    
    return "📬 Hai ricevuto una notifica!"
