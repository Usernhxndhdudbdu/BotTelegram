from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from typing import Dict, List
from config import EMOJI

def create_menu_keyboard(db) -> InlineKeyboardMarkup:
    """Create main menu keyboard"""
    builder = InlineKeyboardBuilder()
    
    categories = db.get_categories()
    for category in categories:
        builder.add(InlineKeyboardButton(
            text=category,
            callback_data=f"menu_category:{category}"
        ))
    
    # Add sponsor and recruitment buttons
    builder.add(InlineKeyboardButton(
        text="📣 Richiedi Sponsor",
        callback_data="start_sponsor_request"
    ))
    
    builder.add(InlineKeyboardButton(
        text="📝 Invia Curriculum", 
        callback_data="start_application"
    ))
    
    # Arrange in 2 columns for categories, 1 for others
    builder.adjust(2, 1, 1)
    return builder.as_markup()

def create_category_keyboard(category: str, items: Dict, db=None, user_id: int = None) -> InlineKeyboardMarkup:
    """Create category items keyboard"""
    builder = InlineKeyboardBuilder()
    
    for item_name, item_data in items.items():
        builder.add(InlineKeyboardButton(
            text=f"🛒 {item_name} - {item_data['price']}€",
            callback_data=f"add_to_cart:{category}:{item_name}"
        ))
    
    # Cart and navigation buttons
    cart_count = 0
    if db and user_id:
        cart_count = db.get_cart_count(user_id)
    
    cart_text = f"🛒 Carrello ({cart_count})" if cart_count > 0 else "🛒 Carrello"
    builder.add(InlineKeyboardButton(
        text=cart_text,
        callback_data="view_cart"
    ))
    
    builder.add(InlineKeyboardButton(
        text=f"{EMOJI['back']} Torna al Menù",
        callback_data="menu_back"
    ))
    
    builder.adjust(1)  # One button per row
    return builder.as_markup()

def create_cart_keyboard(db, user_id: int) -> InlineKeyboardMarkup:
    """Create shopping cart keyboard"""
    builder = InlineKeyboardBuilder()
    cart = db.get_user_cart(user_id)
    
    for item in cart:
        builder.add(InlineKeyboardButton(
            text=f"❌ {item['item_name']} (x{item['quantity']})",
            callback_data=f"remove_from_cart:{item['item_name']}"
        ))
    
    if cart:
        builder.add(InlineKeyboardButton(
            text=f"✅ Conferma Ordine ({db.get_cart_total(user_id)}€)",
            callback_data="confirm_cart_order"
        ))
        
        builder.add(InlineKeyboardButton(
            text="🗑️ Svuota Carrello",
            callback_data="clear_cart"
        ))
    
    builder.add(InlineKeyboardButton(
        text="🔙 Torna al Menù",
        callback_data="menu_back"
    ))
    
    builder.adjust(1)
    return builder.as_markup()

def create_order_confirmation_keyboard(category: str, item_name: str, price: int) -> InlineKeyboardMarkup:
    """Create order confirmation keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text=f"{EMOJI['confirm']} Conferma Ordine",
        callback_data=f"confirm_order:{category}:{item_name}:{price}"
    ))
    
    builder.add(InlineKeyboardButton(
        text=f"{EMOJI['cancel']} Annulla",
        callback_data=f"menu_category:{category}"
    ))
    
    builder.adjust(1)
    return builder.as_markup()

def create_staff_order_keyboard(order_id: str, status: str = "pending") -> InlineKeyboardMarkup:
    """Create staff order management keyboard"""
    builder = InlineKeyboardBuilder()
    
    if status == "pending":
        builder.add(InlineKeyboardButton(
            text="🟢 Prendi in Carico",
            callback_data=f"staff_order:take:{order_id}"
        ))
        builder.add(InlineKeyboardButton(
            text="❌ Rifiuta",
            callback_data=f"staff_order:reject:{order_id}"
        ))
    elif status == "preparing":
        builder.add(InlineKeyboardButton(
            text="✅ Segnala Pronto",
            callback_data=f"staff_order:ready:{order_id}"
        ))
        builder.add(InlineKeyboardButton(
            text="❌ Rifiuta",
            callback_data=f"staff_order:reject:{order_id}"
        ))
    
    if status not in ["rejected", "ready"]:
        builder.add(InlineKeyboardButton(
            text="💬 Rispondi al Cliente",
            callback_data=f"staff_reply:order:{order_id}"
        ))
    
    builder.adjust(2, 1)
    return builder.as_markup()

def create_sponsor_request_keyboard() -> InlineKeyboardMarkup:
    """Create sponsor request keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="📤 Invia Messaggio Sponsor",
        callback_data="start_sponsor_request"
    ))
    
    return builder.as_markup()

def create_staff_sponsor_keyboard(sponsor_id: str) -> InlineKeyboardMarkup:
    """Create staff sponsor management keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="✅ Approva",
        callback_data=f"staff_sponsor:approve:{sponsor_id}"
    ))
    
    builder.add(InlineKeyboardButton(
        text="❌ Rifiuta", 
        callback_data=f"staff_sponsor:reject:{sponsor_id}"
    ))
    
    builder.add(InlineKeyboardButton(
        text="💬 Rispondi",
        callback_data=f"staff_reply:sponsor:{sponsor_id}"
    ))
    
    builder.adjust(2, 1)
    return builder.as_markup()

def create_recruitment_start_keyboard() -> InlineKeyboardMarkup:
    """Create recruitment start keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="📝 Inizia Candidatura",
        callback_data="start_application"
    ))
    
    return builder.as_markup()

def create_staff_application_keyboard(app_id: str) -> InlineKeyboardMarkup:
    """Create staff application management keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="✅ Approva",
        callback_data=f"staff_application:approve:{app_id}"
    ))
    
    builder.add(InlineKeyboardButton(
        text="❌ Rifiuta",
        callback_data=f"staff_application:reject:{app_id}"
    ))
    
    builder.add(InlineKeyboardButton(
        text="💬 Rispondi",
        callback_data=f"staff_reply:application:{app_id}"
    ))
    
    builder.adjust(2, 1)
    return builder.as_markup()

def create_admin_menu_keyboard(categories: List[str]) -> InlineKeyboardMarkup:
    """Create admin menu management keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="📊 Visualizza Statistiche",
        callback_data="admin_menu:view_stats"
    ))
    
    builder.add(InlineKeyboardButton(
        text="💾 Backup Dati",
        callback_data="admin_menu:backup"
    ))
    
    builder.add(InlineKeyboardButton(
        text="🔧 Modifica Categorie",
        callback_data="admin_menu:edit_categories"
    ))
    
    builder.adjust(1)
    return builder.as_markup()

def create_admin_menu_keyboard(db) -> InlineKeyboardMarkup:
    """Create admin menu management keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="➕ Aggiungi Piatto",
        callback_data="add_menu_item"
    ))
    
    builder.add(InlineKeyboardButton(
        text="✏️ Modifica Piatto",
        callback_data="edit_menu_item"
    ))
    
    builder.add(InlineKeyboardButton(
        text="❌ Rimuovi Piatto", 
        callback_data="remove_menu_item"
    ))
    
    builder.adjust(1)
    return builder.as_markup()

def create_menu_edit_keyboard(categories: List[str]) -> InlineKeyboardMarkup:
    """Create menu editing keyboard"""
    builder = InlineKeyboardBuilder()
    
    for category in categories:
        builder.add(InlineKeyboardButton(
            text=f"✏️ {category}",
            callback_data=f"edit_category:{category}"
        ))
    
    builder.add(InlineKeyboardButton(
        text="➕ Nuova Categoria",
        callback_data="add_category"
    ))
    
    builder.adjust(2, 1)
    return builder.as_markup()
